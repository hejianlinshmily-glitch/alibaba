import { read, utils } from './vendor/xlsx.mjs';
import { normalizeMatrix, identifyMatrix, inferDates } from './rules.mjs';
export async function readUpload(file){
  if(file.size>20*1024*1024)throw new Error('文件超过20MB，请分周期导出。');
  const buf=await file.arrayBuffer();let wb;
  if(/\.csv$/i.test(file.name)){
    let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(buf);}catch{text=new TextDecoder('gb18030').decode(buf);}
    wb=read(text,{type:'string',raw:true});
  }else wb=read(new Uint8Array(buf),{type:'array',cellDates:false});
  const candidates=[],errors=[];
  for(const name of wb.SheetNames){
    try{const matrix=utils.sheet_to_json(wb.Sheets[name],{header:1,defval:null,raw:true}),{mode,metric}=identifyMatrix(matrix),rows=normalizeMatrix(matrix);
      candidates.push({name,mode,metric,rows,...inferDates(name+' '+file.name)});
    }catch(e){errors.push(`${name}：${e.message}`);}
  }
  if(!candidates.length)throw new Error(errors.join('\n'));return candidates;
}
