import {validateRecord} from './rules.mjs';
// Keep the existing key so the user's KA history is available after updating.
export const STORAGE='corefly-promotion-template:v1';
export const STORES_STORAGE=STORAGE+':stores';
export function storeName(value){
  if(typeof value!=='string'||!value.trim())throw new Error('请输入店铺名称。');
  const name=value.trim();if(name.length>80)throw new Error('店铺名称最多80个字符。');return name;
}
export function storeList(names=[],records=[]){
  if(!Array.isArray(names))throw new Error('店铺列表格式无效。');
  return [...new Set([...names.map(storeName),...records.map(r=>storeName(r.store))])];
}
export function loadWorkspace(storage){
  try{
    const v=JSON.parse(storage.getItem(STORAGE)||'[]');
    const records=(Array.isArray(v)?v:v?.records??[]).map(validateRecord);
    const names=Array.isArray(v)?JSON.parse(storage.getItem(STORES_STORAGE)||'[]'):v?.stores??[];
    return {records,stores:storeList(names,records)};
  }catch{return {records:[],stores:[]};}
}
export function loadHistory(storage){
  return loadWorkspace(storage).records;
}
export function saveWorkspace(storage,{records,stores}){
  const names=storeList(stores,records);
  // Keep the records array readable by previous template releases.
  storage.setItem(STORAGE,JSON.stringify(records));
  storage.setItem(STORES_STORAGE,JSON.stringify(names));
}
export function clearHistory(storage){storage.removeItem(STORES_STORAGE);storage.removeItem(STORAGE);}
export function mergeHistory(existing,incoming){
  const map=new Map(existing.map(r=>[r.key,r]));for(const record of incoming){const r=validateRecord(record);map.set(r.key,r);}return [...map.values()];
}
export function addStore(stores,value){
  const name=storeName(value);if(stores.includes(name))throw new Error('这个店铺已存在，请直接选择。');return [...stores,name];
}
export function renameStore({records,stores},from,value){
  const name=storeName(value);if(!stores.includes(from))throw new Error('请先选择要重命名的店铺。');
  if(name!==from&&stores.includes(name))throw new Error('该名称已被其他店铺使用。请用“修改所属店铺”移动单份记录。');
  return {stores:stores.map(s=>s===from?name:s),records:records.map(r=>r.store===from?validateRecord({...r,store:name}):r)};
}
export function moveRecord(records,key,value){
  const name=storeName(value),current=records.find(r=>r.key===key);if(!current)throw new Error('找不到要修改的记录。');
  const moved=validateRecord({...current,store:name});
  if(records.some(r=>r.key!==key&&r.key===moved.key))throw new Error('目标店铺已有同推广方式、同周期记录。此次修改未保存，请先核对两份记录。');
  return {records:records.map(r=>r.key===key?moved:r),record:moved};
}
