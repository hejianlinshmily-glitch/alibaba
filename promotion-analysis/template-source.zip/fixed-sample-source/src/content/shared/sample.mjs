import {validateRecord} from './rules.mjs';
// Fictional records only. Never embed a user's business spreadsheet in this sample.
function rows(multiplier=1){return [[101,'模拟商品A',160,80,10],[102,'模拟商品B',240,60,5],[103,'模拟商品C',360,70,5],[104,'模拟商品D',100,20,2],[105,'模拟商品E',100,35,0],[106,'模拟商品F',0,0,0]].map(([id,title,spend,clicks,inquiries])=>({id:String(id),title,spend:spend*multiplier,clicks,inquiries,exposures:clicks*20,original:{备注:'虚拟演示数据',商品ID:String(id),商品标题:title,消耗:spend*multiplier,点击次数:clicks,询盘次数:inquiries}}));}
export function sampleWorkspace(){
  const stores=['演示店铺A','演示店铺B'],records=[];
  for(const [store,mode,factor] of [['演示店铺A','KA方案',1],['演示店铺B','全站推店',1.4]]){
    for(const [start,end,m] of [['2026-08-01','2026-08-31',1.2],['2026-09-01','2026-09-30',1]])records.push(validateRecord({store,mode,start,end,file:'虚拟演示数据（非经营报表）',sheet:'固定样本',rows:rows(factor*m),importedAt:'2026-10-05T09:10:00Z',ruleVersion:'1.1'}));
  }
  return {stores,records};
}
