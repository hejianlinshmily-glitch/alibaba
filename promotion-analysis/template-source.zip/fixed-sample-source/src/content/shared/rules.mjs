export const RULES = Object.freeze({version:'1.1', low:0.8, high:1.5, minClicks:30, minInquiries:5, zeroSpendMultiple:2});
export const MODES = Object.freeze({'KA方案':{metric:'有效询盘量'},'全站推店':{metric:'询盘量'}});
export const CATEGORIES = ['成本偏高','高消耗无询盘','成本较低','成本正常','样本不足','尚未消耗'];
export const money = v => v == null || !Number.isFinite(v) ? '—' : new Intl.NumberFormat('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2}).format(v);
export const count = v => v == null ? '—' : new Intl.NumberFormat('zh-CN').format(v);
export function summarize(rows) {
  const sum = key => rows.reduce((s,r)=>s+r[key],0);
  const spend=sum('spend'), inquiries=sum('inquiries'), clicks=sum('clicks');
  const exposures = rows.every(r=>r.exposures!=null) ? sum('exposures') : null;
  return {spend,inquiries,clicks,exposures,baseline:inquiries>0?spend/inquiries:null,
    cpc:clicks>0?spend/clicks:null,ctr:exposures>0?clicks/exposures:null,
    inquiryRate:clicks>0?inquiries/clicks:null,products:rows.length};
}
export function classify(row,T) {
  const cost=row.inquiries>0?row.spend/row.inquiries:null;
  const relative=cost!=null&&T>0?cost/T:null;
  let category,reason;
  if(row.spend===0){category='尚未消耗';reason='消耗为0，暂不评价付费效果';}
  else if(row.inquiries===0 && row.clicks>=RULES.minClicks && T>0 && row.spend>=RULES.zeroSpendMultiple*T){
    category='高消耗无询盘';reason=`询盘0次、点击${row.clicks}次，消耗达到基线的${RULES.zeroSpendMultiple}倍`;}
  else if(row.clicks<RULES.minClicks || row.inquiries<RULES.minInquiries){
    category='样本不足';reason=`点击${row.clicks}次、询盘${row.inquiries}次；门槛为30次点击且5次询盘`;}
  else if(relative==null){category='样本不足';reason='当前没有可比较的成本基线';}
  else if(relative<=RULES.low){category='成本较低';reason=`达到样本门槛，询盘成本≤${RULES.low}倍基线`;}
  else if(relative>RULES.high){category='成本偏高';reason=`达到样本门槛，询盘成本>${RULES.high}倍基线`;}
  else {category='成本正常';reason=`达到样本门槛，询盘成本在${RULES.low}～${RULES.high}倍基线之间`;}
  return {...row,cost,relative,category,reason,inquiryRate:row.clicks>0?row.inquiries/row.clicks:null};
}
export function analyze(rows) { const totals=summarize(rows);return {totals,rows:rows.map(r=>classify(r,totals.baseline))}; }
export function recordKey(r){return JSON.stringify([r.store,r.mode??'KA方案',r.start,r.end]);}
export function validDates(start,end){return /^\d{4}-\d{2}-\d{2}$/.test(start)&&/^\d{4}-\d{2}-\d{2}$/.test(end)&&!isNaN(Date.parse(start))&&!isNaN(Date.parse(end))&&new Date(start).toISOString().slice(0,10)===start&&new Date(end).toISOString().slice(0,10)===end&&start<=end;}
export function days(r){return Math.round((Date.parse(r.end)-Date.parse(r.start))/86400000)+1;}
export function overlap(a,b){return a.store===b.store&&(a.mode??'KA方案')===(b.mode??'KA方案')&&a.start<=b.end&&b.start<=a.end;}
export function numberCell(v,label,rowNum,integer=false){
  if(v==null || String(v).trim()==='')throw new Error(`第${rowNum}行的“${label}”为空，请补齐后导入。`);
  const n=typeof v==='number'?v:Number(String(v).trim().replace(/[,，￥¥\s]/g,''));
  if(!Number.isFinite(n)||n<0||(integer&&!Number.isInteger(n)))throw new Error(`第${rowNum}行的“${label}”不是有效${integer?'非负整数':'非负数字'}。`);
  return n;
}
export function identifyMatrix(matrix){
  const common={id:['商品id','商品ID','商品Id','商品编号']};
  const formats=[{mode:'KA方案',aliases:{...common,title:['推广信息标题','商品标题','商品名称'],spend:['消耗'],clicks:['点击次数'],inquiries:['有效询盘量'],exposures:['展现次数']}},
    {mode:'全站推店',aliases:{...common,title:['offer标题','商品标题','商品名称'],spend:['消耗量'],clicks:['点击量'],inquiries:['询盘量'],exposures:['曝光量']}}];
  const cleaned=matrix.map(r=>r.map(v=>String(v??'').trim()));
  const matches=formats.map(f=>({...f,hi:cleaned.findIndex((r,i)=>i<20&&['id','spend','inquiries'].every(k=>f.aliases[k].some(x=>r.includes(x))))})).filter(f=>f.hi>=0);
  if(!matches.length)throw new Error('未识别到推广商品表。支持 KA：商品ID、消耗、点击次数、有效询盘量；全站推店：商品ID、消耗量、点击量、询盘量。');
  if(matches.length>1)throw new Error('同一工作表同时包含 KA 和全站字段，请将两种推广方式分别导出。');
  const {mode,aliases,hi}=matches[0];return {mode,metric:MODES[mode].metric,aliases,hi,headers:cleaned[hi]};
}
export function normalizeMatrix(matrix){
  const {aliases,hi,headers}=identifyMatrix(matrix),idx=Object.fromEntries(Object.entries(aliases).map(([k,names])=>[k,headers.findIndex(h=>names.includes(h))]));
  for(const k of ['id','spend','clicks','inquiries'])if(idx[k]<0)throw new Error(`缺少必要字段：${aliases[k][0]}`);
  for(const k of ['id','spend','clicks','inquiries'])if(headers.filter(h=>aliases[k].includes(h)).length!==1)throw new Error(`字段重复：${aliases[k][0]}`);
  const seen=new Set(),rows=[];
  for(let i=hi+1;i<matrix.length;i++){
    const r=matrix[i];if(r.every(v=>v==null||String(v).trim()===''))continue;
    if(['合计','总计','汇总'].includes(String(r[idx.id]??'').trim()))continue;
    const id=String(r[idx.id]??'').trim();if(!/^\d+$/.test(id))throw new Error(`第${i+1}行商品ID不正确，请检查空ID或汇总行。`);
    if(typeof r[idx.id]==='number'&&!Number.isSafeInteger(r[idx.id]))throw new Error(`商品ID精度不足，请以文本导出：第${i+1}行。`);
    if(seen.has(id))throw new Error(`商品ID重复：${id}。请确认每个商品在这个周期只有一行。`);seen.add(id);
    const spend=numberCell(r[idx.spend],headers[idx.spend],i+1), clicks=numberCell(r[idx.clicks],headers[idx.clicks],i+1,true),inquiries=numberCell(r[idx.inquiries],headers[idx.inquiries],i+1,true);
    const exposures=idx.exposures>=0?numberCell(r[idx.exposures],headers[idx.exposures],i+1,true):null;
    rows.push({id,title:idx.title>=0?String(r[idx.title]??''):id,spend,clicks,inquiries,exposures,
      original:Object.fromEntries(headers.filter(Boolean).map(h=>[h,r[headers.indexOf(h)]??null]))});
  }
  if(!rows.length)throw new Error('表格没有商品记录。');return rows;
}
export function inferDates(text){const dates=text.match(/20\d{2}[-/]\d{2}[-/]\d{2}/g)||[];return dates.length>=2?{start:dates[0].replaceAll('/','-'),end:dates[1].replaceAll('/','-')}:{start:'',end:''};}
export function validateRecord(r){
  if(!r||typeof r.store!=='string'||!r.store.trim()||!validDates(r.start,r.end)||!Array.isArray(r.rows)||!r.rows.length)throw new Error('备份中的店铺、周期或商品记录无效。');
  const mode=r.mode??'KA方案';if(!Object.hasOwn(MODES,mode))throw new Error('备份中的推广方式无效。');
  const ids=new Set();for(const row of r.rows){if(!/^\d+$/.test(row.id)||ids.has(row.id))throw new Error('备份包含无效或重复商品ID。');ids.add(row.id);for(const k of ['spend','clicks','inquiries'])numberCell(row[k],k,0,k!=='spend');if(row.exposures!=null)numberCell(row.exposures,'展现次数',0,true);}
  return {...r,store:r.store.trim(),mode,metric:MODES[mode].metric,key:recordKey({...r,store:r.store.trim(),mode}),rows:r.rows.map(row=>({...row,title:String(row.title??row.id),spend:numberCell(row.spend,'消耗',0),clicks:numberCell(row.clicks,'点击次数',0,true),inquiries:numberCell(row.inquiries,MODES[mode].metric,0,true),exposures:row.exposures==null?null:numberCell(row.exposures,'展现次数',0,true)}))};
}
