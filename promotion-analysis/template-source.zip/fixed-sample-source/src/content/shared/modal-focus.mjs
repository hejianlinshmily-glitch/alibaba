export function focusDialogOnce(root){
  const target=root?.querySelector('[data-autofocus],input:not([type="hidden"]):not(:disabled),select:not(:disabled),button:not(:disabled)')??root;
  target?.focus();
}
export function isConfirmedEnter(event){
  return event.key==='Enter'&&!event.isComposing&&!event.nativeEvent?.isComposing&&event.keyCode!==229;
}
