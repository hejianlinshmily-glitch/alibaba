import {analyze,summarize,days} from './rules.mjs';
export function summarizeHistory(records,store,mode){
  const selected=records.filter(r=>r.store===store&&r.mode===mode).sort((a,b)=>a.start.localeCompare(b.start)||a.end.localeCompare(b.end));
  let lastEnd='',hasOverlap=false,previous=null;
  const periods=selected.map(r=>{
    if(lastEnd&&r.start<=lastEnd)hasOverlap=true;if(r.end>lastEnd)lastEnd=r.end;
    const model=analyze(r.rows),baseline=model.totals.baseline;
    const costChange=baseline!=null&&previous>0?(baseline-previous)/previous:null;
    previous=baseline;
    return {key:r.key,store:r.store,mode:r.mode,metric:r.metric,start:r.start,end:r.end,period:`${r.start} 至 ${r.end}`,days:days(r),...model.totals,costChange,highProducts:model.rows.filter(p=>p.category==='成本偏高'||p.category==='高消耗无询盘').length};
  });
  return {selected,periods,hasOverlap,totals:hasOverlap||!selected.length?null:summarize(selected.flatMap(r=>r.rows))};
}
